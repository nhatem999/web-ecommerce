
<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('main_class', 'detail-blog-page'); ?>
<?php $__env->startSection('content'); ?>
<div class="secion" id="breadcrumb-wp">
<div class="secion-detail">
    <ul class="list-item clearfix">
        <li>
            <a href="<?php echo e(route('user.index')); ?>" title="">Trang chủ</a>
        </li>
        <li>
            <a href="<?php echo e(route('user.blog')); ?>" title="">Blog</a>
        </li>
        <li>
            <a href="<?php echo e(route('user.blog', $catName->slug)); ?>" title=""><?php echo e($catName->name); ?></a>
        </li>
    </ul>
</div>
</div>
<div class="main-content fl-right">
<div class="section" id="detail-blog-wp">
    <div class="section-head clearfix">
        <h3 class="section-title"><?php echo e($post->title); ?></h3>
    </div>
    <div class="section-detail">
        <div>
            <span class="author-post"><?php echo e($post->user->name); ?></span>
            <span class="create-date"><?php echo e(date('d/m/Y', strtotime($post->created_at))); ?></span>
        </div>
        <div class="detail">
            <?php echo $post->content; ?>

        </div>
    </div>
</div>
<div class="section" id="social-wp">
    <div class="section-detail">
        <div class="fb-like" data-href="" data-layout="button_count" data-action="like" data-size="small"
            data-show-faces="true" data-share="true"></div>
        <div class="g-plusone-wp">
            <div class="g-plusone" data-size="medium"></div>
        </div>
        <div class="fb-comments" id="fb-comment" data-href="" data-numposts="5"></div>
    </div>
</div>
</div>
<?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/user/blog/detail.blade.php ENDPATH**/ ?>