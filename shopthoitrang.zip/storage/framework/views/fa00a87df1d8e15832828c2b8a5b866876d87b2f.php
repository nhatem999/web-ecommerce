
<?php $__env->startSection('title', 'Lỗi'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0">Bạn không có quyền vào trang này</h5>
            </div>
            <div class="card-body">
                <div class="text-center">
                    <img style="max-width: 40%" src="<?php echo e(asset('public/admins/img/error-page.jpg')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/errors/403.blade.php ENDPATH**/ ?>