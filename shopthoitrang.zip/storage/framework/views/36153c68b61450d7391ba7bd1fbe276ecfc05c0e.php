
<?php $__env->startSection('title', 'Danh sách đơn hàng'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách đơn hàng</h5>
                <div class="form-search form-inline">
                    <form action="">
                        <input type="text" class="form-control form-search" name="kw" placeholder="Tìm kiếm tên sản phẩm"
                            value="<?php echo e(request()->kw); ?>">
                        <input type="submit" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('errors')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('errors')); ?>

                    </div>
                <?php endif; ?>
                <div class="analytic">
                    <a href="<?php echo e(route('order.index')); ?>?status=all" class="text-primary">Tất cả
                        <span class="text-muted">(<?php echo e($count['all']); ?>)</span></a>
                    <a href="<?php echo e(route('order.index')); ?>?status=processing" class="text-primary">Đang xử lý<span
                            class="text-muted">(<?php echo e($count['processing']); ?>)</span></a>
                    <a href="<?php echo e(route('order.index')); ?>?status=delivery" class="text-primary">Đang giao<span
                            class="text-muted">(<?php echo e($count['delivery']); ?>)</span></a>
                    <a href="<?php echo e(route('order.index')); ?>?status=complete" class="text-primary">Hoàn thành<span
                            class="text-muted">(<?php echo e($count['complete']); ?>)</span></a>
                    <a href="<?php echo e(route('order.index')); ?>?status=cancel" class="text-primary">Hủy đơn
                        hóa<span class="text-muted">(<?php echo e($count['cancel']); ?>)</span></a>
                </div>
                <form action="<?php echo e(route('order.action')); ?>">
                    <div class="form-action form-inline py-3">
                        <?php if(Auth::user()->can('cap-nhat-don-hang')): ?>
                            <select class="form-control mr-1" id="" name="act">
                                <option value="">Chọn</option>
                                <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                        <?php endif; ?>
                    </div>
                    <table class="table table-striped table-checkall" id="list-product">
                        <thead class="text-center">
                            <tr>
                                <th scope="col">
                                    <input name="checkall" type="checkbox">
                                </th>
                                <th scope="col">STT</th>
                                <th scope="col">Mã đơn hàng</th>
                                <th scope="col">Họ và tên</th>
                                <th scope="col">Số sản phẩm</th>
                                <th scope="col">Tổng giá</th>
                                <th scope="col">Trang thái</th>
                                <th scope="col">Thời gian</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php if($orders->count() > 0): ?>
                                <?php
                                    $t = 1;
                                ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="list_check[]" value="<?php echo e($item->id); ?>">
                                        </td>
                                        <td scope="row"><?php echo e($t++); ?></td>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->customer->name); ?></td>
                                        <td><?php echo e($item->orderDetails->sum('quantity')); ?></td>
                                        <td><?php echo e(number_format($item->total, 0, ',', '.')); ?>đ</td>
                                        <?php if($item->status == 0): ?>
                                            <td>
                                                <span
                                                    class="badge <?php echo e(request()->status == 'cancel' ? 'badge-dark' : 'badge-warning'); ?>">
                                                    Đang xử lý</span>
                                            </td>
                                        <?php endif; ?>
                                        <?php if($item->status == 1): ?>
                                            <td><span
                                                    class="badge <?php echo e(request()->status == 'cancel' ? 'badge-dark' : 'badge-info'); ?>">Đang
                                                    giao hàng</span></td>
                                        <?php endif; ?>
                                        <?php if($item->status == 2): ?>
                                            <td><span
                                                    class="badge <?php echo e(request()->status == 'cancel' ? 'badge-dark' : 'badge-success'); ?>">Hoàn
                                                    thành</span></td>
                                        <?php endif; ?>
                                        <td><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></td>
                                        <td>
                                            <?php if(Auth::user()->can('xem-chi-tiet-don-hang')): ?>
                                                <a href="<?php echo e(route('order.seen', ['id' => $item->id])); ?>"
                                                    class="btn btn-info btn-sm rounded-0" data-toggle="tooltip"
                                                    title="Seen"><i class="fas fa-eye"></i></a>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->can('huy-don-hang')): ?>
                                                <?php if(request()->status != 'cancel'): ?>
                                                    <a href="<?php echo e(route('order.cancel', ['id' => $item->id])); ?>"
                                                        onclick="return confirm('Bán có chắc chắn muốn xóa bản ghi này')"
                                                        class="btn btn-danger btn-sm rounded-0" data-toggle="tooltip"
                                                        title="Delete"><i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9">Không có bản ghi nào</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
                <?php echo e($orders->appends(request()->input())->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/admin/order/list.blade.php ENDPATH**/ ?>