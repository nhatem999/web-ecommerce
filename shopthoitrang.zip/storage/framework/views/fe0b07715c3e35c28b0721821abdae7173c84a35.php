
<?php $__env->startSection('title'); ?>
    <?php echo e($catProduct->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_class', 'category-product-page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="secion" id="breadcrumb-wp">
        <div class="secion-detail">
            <ul class="list-item clearfix">
                <li>
                    <a href="<?php echo e(route('user.index')); ?>" title="">Trang chủ</a>
                </li>
                <?php if($catProduct->parent_id == 0): ?>
                    <li>
                        <a href="<?php echo e(route('user.category', $catProduct->slug)); ?>" title=""><?php echo e($catProduct->name); ?></a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('user.category', $catProduct->catProductParent->slug)); ?>"
                            title=""><?php echo e($catProduct->catProductParent->name); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user.category', $catProduct->slug)); ?>" title=""><?php echo e($catProduct->name); ?></a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="main-content fl-right">
        <div class="section" id="list-product-wp">
            <div class="section-head clearfix">
                <div class="fl-left">
                    <a href="<?php echo e(route('user.category', ['slugCategory' => $catProduct->slug])); ?>"
                        class="section-title"><?php echo e($catProduct->name); ?></a>
                    <?php if(!empty($checkBrand) || !empty($checkPrice)): ?>
                        <div class="filter-product">
                            <span class="filter-title">Lọc theo: </span>
                            <?php if(!empty($checkBrand)): ?>
                                <?php $__currentLoopData = $checkBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="filter-name"><?php echo e($item); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if(!empty($checkPrice)): ?>
                                <span class="filter-name"><?php echo e($checkPrice); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="filter-wp fl-right">
                    <div class="form-filter">
                        <form>
                            <select name="sort">
                                <option>Sắp xếp</option>
                                <option <?php echo e(request()->sort == 'a-z' ? 'selected' : ''); ?> value="a-z">Từ A-Z</option>
                                <option <?php echo e(request()->sort == 'z-a' ? 'selected' : ''); ?> value="z-a">Từ Z-A</option>
                                <option <?php echo e(request()->sort == 'high-to-low' ? 'selected' : ''); ?> value="high-to-low">Giá
                                    cao xuống thấp</option>
                                <option <?php echo e(request()->sort == 'low-to-high' ? 'selected' : ''); ?> value="low-to-high">Giá
                                    thấp lên cao</option>
                            </select>
                            <button type="submit">Lọc</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="section-detail">
                <?php if($products->count() > 0): ?>
                    <ul class="list-item clearfix">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="product-laptop">
                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                    title="" class="thumb">
                                    <img src="<?php echo e(asset($item->feature_image)); ?>">
                                </a>
                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                    title="" class="product-name"><?php echo e($item->name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                </div>
                                <div class="action clearfix">
                                    <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title="Thêm giỏ hàng"
                                        class="add-cart fl-left"
                                        data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>">Thêm giỏ hàng</a>
                                    <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua ngay</a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <div class="not-search clearfix">
                        <img src="<?php echo e(asset('public/users/images/noti-search.png')); ?>" alt="">
                        <p>Rất tiếc chúng tôi không tìm thấy kết quả theo yêu cầu của bạn</p>
                        <p>Vui lòng thử lại .</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="section" id="paging-wp">
            <div class="section-detail">
                <?php echo e($products->links()); ?>

            </div>
        </div>

        
        <?php echo $__env->make('user.components.modalProductCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->make('user.components.modalNotification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
    <?php echo $__env->make('user.product.componentSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/user/product/category.blade.php ENDPATH**/ ?>