
<?php $__env->startSection('title', 'Yolo Store'); ?>
<?php $__env->startSection('main_class', 'home-page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content fl-right">
        
        <?php echo $__env->make('user.components.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="section" id="support-wp">
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <li>
                        <div class="thumb">
                            <img src="public/users/images/icon-1.png">
                        </div>
                        <h3 class="title">Miễn phí vận chuyển</h3>
                        <p class="desc">Tới tận tay khách hàng</p>
                    </li>
                    <li>
                        <div class="thumb">
                            <img src="public/users/images/icon-2.png">
                        </div>
                        <h3 class="title">Tư vấn 24/7</h3>
                        <p class="desc">1900.9999</p>
                    </li>
                    <li>
                        <div class="thumb">
                            <img src="public/users/images/icon-3.png">
                        </div>
                        <h3 class="title">Tiết kiệm hơn</h3>
                        <p class="desc">Với nhiều ưu đãi cực lớn</p>
                    </li>
                    <li>
                        <div class="thumb">
                            <img src="public/users/images/icon-4.png">
                        </div>
                        <h3 class="title">Thanh toán nhanh</h3>
                        <p class="desc">Hỗ trợ nhiều hình thức</p>
                    </li>
                    <li>
                        <div class="thumb">
                            <img src="public/users/images/icon-5.png">
                        </div>
                        <h3 class="title">Đặt hàng online</h3>
                        <p class="desc">Thao tác đơn giản</p>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="section" id="feature-product-wp">
            <div class="section-head">
                <h3 class="section-title">Sản phẩm nổi bật</h3>
            </div>
            <div class="section-detail">
                <ul class="list-item">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php if($item->discount > 0): ?>
                                <div class="sale-off">
                                    <span class="sale-off-percent"><?php echo e($item->discount); ?>%</span>
                                    <span class="sale-off-label">GIẢM</span>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="thumb">

                                <div class="product_image">
                                    <img src="<?php echo e(asset($item->feature_image)); ?>">
                                    
                                </div>

                            </a>
                            <a href="?page=detail_product" title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <?php if($item->discount): ?>
                                    <?php
                                        $discount = $item->price - ($item->price * $item->discount) / 100;
                                    ?>
                                    <span class="new"><?php echo e(number_format($discount, 0, '', '.')); ?>đ</span>
                                    <span class="old"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php else: ?>
                                    <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php endif; ?>
                            </div>
                            <div class="action clearfix">
                                <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title=""
                                    class="add-cart fl-left" data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>" data-account="<?php echo e(Auth::guard('account')->check() ? true : false); ?>" data-quantity="<?php echo e($item->quantity); ?>" data-verify="<?php echo e(Auth::guard('account')->check() && Auth::guard('account')->user()->verify_account == 1 ? 1: 0); ?>">Thêm
                                    giỏ hàng</a>
                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                    title="" class="buy-now fl-right">Xem chi tiết</a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        

        
        <div class="section" id="list-product-wp">
            <div class="section-head">
                <a href="<?php echo e(route('user.category', ['slugCategory' => 'ao-thun'])); ?>" class="section-title">Áo Thun</a>
            </div>
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <?php $__currentLoopData = $productShirt1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php if($item->discount > 0): ?>
                                <div class="sale-off">
                                    <span class="sale-off-percent"><?php echo e($item->discount); ?>%</span>
                                    <span class="sale-off-label">GIẢM</span>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="thumb">
                                <div class="product_image">
                                    <img src="<?php echo e(asset($item->feature_image)); ?>">
                                    <?php if($item->feature_image2): ?>
                                        <img src="<?php echo e(asset($item->feature_image2)); ?>">
                                    <?php endif; ?>
                                </div>
                            </a>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <?php if($item->discount): ?>
                                    <?php
                                        $discount = $item->price - ($item->price * $item->discount) / 100;
                                    ?>
                                    <span class="new"><?php echo e(number_format($discount, 0, '', '.')); ?>đ</span>
                                    <span class="old"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php else: ?>
                                    <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php endif; ?>
                            </div>
                            <div class="action clearfix">
                                <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title="Thêm giỏ hàng"
                                    class="add-cart fl-left" data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>" data-account="<?php echo e(Auth::guard('account')->check() ? true : false); ?>" data-verify="<?php echo e(Auth::guard('account')->check() && Auth::guard('account')->user()->verify_account == 1 ? 1: 0); ?>" data-quantity="<?php echo e($item->quantity); ?>">Thêm
                                    giỏ hàng</a>
                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                    title="Mua ngay" class="buy-now fl-right">Xem chi tiết</a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        

        
        <div class="section" id="list-product-wp">
            <div class="section-head">
                <a href="<?php echo e(route('user.category', ['slugCategory' => 'ao-so-mi'])); ?>" class="section-title">Áo Sơ
                    Mi</a>
            </div>
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <?php $__currentLoopData = $productShirt2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="">
                            <?php if($item->discount > 0): ?>
                                <div class="sale-off">
                                    <span class="sale-off-percent"><?php echo e($item->discount); ?>%</span>
                                    <span class="sale-off-label">GIẢM</span>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="thumb">
                                <div class="product_image">
                                    <img src="<?php echo e(asset($item->feature_image)); ?>">
                                    <?php if($item->feature_image2): ?>
                                        <img src="<?php echo e(asset($item->feature_image2)); ?>">
                                    <?php endif; ?>
                                </div>
                            </a>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <?php if($item->discount): ?>
                                    <?php
                                        $discount = $item->price - ($item->price * $item->discount) / 100;
                                    ?>
                                    <span class="new"><?php echo e(number_format($discount, 0, '', '.')); ?>đ</span>
                                    <span class="old"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php else: ?>
                                    <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php endif; ?>
                            </div>
                            <div class="action clearfix">
                                <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title="Thêm giỏ hàng"
                                    class="add-cart fl-left" data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>" data-account="<?php echo e(Auth::guard('account')->check() ? true : false); ?>" data-verify="<?php echo e(Auth::guard('account')->check() && Auth::guard('account')->user()->verify_account == 1 ? 1: 0); ?>" data-quantity="<?php echo e($item->quantity); ?>">Thêm
                                    giỏ hàng</a>
                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                    title="Mua ngay" class="buy-now fl-right">Xem chi tiết</a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        
        
        <div class="section" id="list-product-wp">
            <div class="section-head">
                <a href="<?php echo e(route('user.category', ['slugCategory' => 'quan-jean'])); ?>" class="section-title">Quần
                    Jean</a>
            </div>
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <?php $__currentLoopData = $productQuanJean; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="">
                            <?php if($item->discount > 0): ?>
                                <div class="sale-off">
                                    <span class="sale-off-percent"><?php echo e($item->discount); ?>%</span>
                                    <span class="sale-off-label">GIẢM</span>
                                </div>
                            <?php endif; ?>

                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="thumb">
                                <div class="product_image">
                                    <img src="<?php echo e(asset($item->feature_image)); ?>">
                                    <?php if($item->feature_image2): ?>
                                        <img src="<?php echo e(asset($item->feature_image2)); ?>">
                                    <?php endif; ?>
                                </div>
                            </a>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <?php if($item->discount): ?>
                                    <?php
                                        $discount = $item->price - ($item->price * $item->discount) / 100;
                                    ?>
                                    <span class="new"><?php echo e(number_format($discount, 0, '', '.')); ?>đ</span>
                                    <span class="old"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php else: ?>
                                    <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                                <?php endif; ?>

                            </div>
                            <div class="action clearfix">
                                <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title="Thêm giỏ hàng"
                                    class="add-cart fl-left" data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>" data-account="<?php echo e(Auth::guard('account')->check() ? true : false); ?>" data-verify="<?php echo e(Auth::guard('account')->check() && Auth::guard('account')->user()->verify_account == 1 ? 1: 0); ?>" data-quantity="<?php echo e($item->quantity); ?>">Thêm
                                    giỏ hàng</a>
                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                    title="Mua ngay" class="buy-now fl-right">Xem chi tiết</a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        
    </div>
    <?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/index.blade.php ENDPATH**/ ?>