
<?php $__env->startSection('title', 'Danh sách ảnh của sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="row">
        <div class="col-4">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Thêm ảnh cho sản phẩm
                </div>
                <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Ảnh slider</label>
                            <input id="img" type="file" name="image_product" class="form-control d-none"
                                onchange="changeImg(this)">
                            <img id="avatar" class="img-thumbnail d-block" width="250px"
                                src="<?php echo e(asset('public/admins/img/upload_img.png')); ?>">
                            <?php $__errorArgs = ['image_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="">Trạng thái</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" value="1" checked>
                                <label class="form-check-label" for="exampleRadios1">
                                    Công khai
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" value="0">
                                <label class="form-check-label" for="exampleRadios2">
                                    Chờ duyệt
                                </label>
                            </div>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Thêm mới">
                    </form>
                </div>
            </div>
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Danh sách ảnh về sản phẩm
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="analytic">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'all'])); ?>" class="text-primary">Tất cả
                            <span class="text-muted">(<?php echo e($count['all']); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'public'])); ?>" class="text-primary">Công
                            khai<span class="text-muted">(<?php echo e($count['public']); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'pending'])); ?>" class="text-primary">Chờ
                            duyệt<span class="text-muted">(<?php echo e($count['pending']); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'trash'])); ?>" class="text-primary">Vô
                            hiệu hóa<span class="text-muted">(<?php echo e($count['trash']); ?>)</span></a>
                    </div>
                    <form action="<?php echo e(route('image.action', ['id' => $product_id])); ?>">
                        <div class="form-action form-inline py-3">
                            <select class="form-control mr-1" id="" name="act">
                                <option value="">Chọn</option>
                                <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                        </div>
                        <table class="table table-striped table-checkall">
                            <thead>
                                <tr>
                                    <th scope="col">
                                        <input name="checkall" type="checkbox">
                                    </th>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên ảnh</th>
                                    <th scope="col" width="14%">Hình ảnh</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($productImages->count() > 0): ?>
                                    <?php
                                        $t = 1;
                                    ?>
                                    <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="list_check[]" value="<?php echo e($item->id); ?>">
                                            </td>
                                            <td scope="row"><?php echo e($t++); ?></td>
                                            <td><?php echo e($item->image_name); ?></td>
                                            <td><img class="img-thumbnail" src="<?php echo e(asset($item->image_product)); ?>"
                                                    alt=""></td>
                                            <td class="text-center">
                                                <?php if(request()->status != 'trash'): ?>
                                                    <a href="<?php echo e(route('image.delete', ['id' => $item->id])); ?>"
                                                        onclick="return confirm('Bán có chắc chắn muốn xóa tạm bản ghi này')"
                                                        class="btn btn-danger btn-sm rounded-0" data-toggle="tooltip"
                                                        title="Delete"><i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5">Không có bản ghi nào</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </form>
                    <?php echo e($productImages->links()); ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/admin/productImage/list.blade.php ENDPATH**/ ?>