
<?php $__env->startSection('title', 'Xác thực tài khoản'); ?>

<?php $__env->startSection('content'); ?>

    <?php if($status): ?>
        <div class="alert alert-success">
            <?php echo e($status); ?>

        </div>
    <?php endif; ?>
    <div>

    </div>
    <form action="" method="POST" style="    text-align: center;
    font-size: large;
    color: blueviolet;
}">
        <?php echo csrf_field(); ?>
        <label for="" style="margin-bottom:10px">Nhập mã xác thực</label><br>
        <input type="text" name="code">
        <button type="submit" name="">Nhập mã</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/login/verifyConfirm.blade.php ENDPATH**/ ?>