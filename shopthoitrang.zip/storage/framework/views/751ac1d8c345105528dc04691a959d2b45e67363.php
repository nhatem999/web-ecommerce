<div id="header-wp">
    
    <div id="head-top" class="clearfix">
        <div class="wp-inner">
            <a href="" title="" id="payment-link" class="fl-left">Hình thức thanh toán</a>
            <div id="main-menu-wp" class="fl-right">
                <ul id="main-menu" class="clearfix">
                    <li>
                        <a href="<?php echo e(route('user.index')); ?>" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user.blog')); ?>" title="">Blog</a>
                    </li>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('user.page', ['id' => $item->id])); ?>"
                                title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        
                        <?php if(Auth::guard('account')->check()): ?>
                        <div class="btn-group">
                            <button style="background-color: #6c757d;
                            color: #fcf8e3;" type="button" class="btn-user dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                    V            aria-expanded="false">
                                <?php echo e(Auth::guard('account')->user()->name); ?>

                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                
                                
                                <a style="color: black"  href="<?php echo e(route('cart.user',Auth::guard('account')->user()->id)); ?>">Thông tin đơn hàng</a>
                                <a style="color: black" href="<?php echo e(route('user.verify')); ?>">Xác thực tài khoản</a>
                                
                                <a style="color: black" class="user-item" href="<?php echo e(route('user.logout')); ?>" onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Thoát')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>

                        <?php else: ?>
                        <a href="<?php echo e(route('user.login')); ?>" title="">Đăng Nhập</a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if(!Auth::guard('account')->check()): ?>
                        <a href="<?php echo e(route('user.register')); ?>">Đăng ký</a>
                        <?php endif; ?>
                    </li>
                    
                </ul>
            </div>
        </div>
    </div>
    <div id="head-body" class="clearfix">
        <div class="wp-inner">
            <a href="<?php echo e(route('user.index')); ?>" title="" id="logo" class="fl-left"><img
                    src="<?php echo e(asset('public/users/images/logo-2.png')); ?>" /></a>
            <div id="search-wp" class="fl-left">
                <form action="<?php echo e(route('user.search')); ?>" autocomplete="off">
                    <input type="text" name="search" id="search" value="<?php echo e(request()->input('search')); ?>"
                        placeholder="Nhập từ khóa tìm kiếm tại đây!" data-url="<?php echo e(route('user.autocomplete')); ?>">
                    <input type="submit" id="sm-search" value="Tìm kiếm" />
                </form>
                <div id="results-search"></div>
            </div>
            <div id="action-wp" class="fl-right">
                <div id="advisory-wp" class="fl-left">
                    <span class="title">Tư vấn</span>
                    <span class="phone">0377.411.577</span>
                </div>
                <div id="btn-respon" class="fl-right"><i class="fa fa-bars" aria-hidden="true"></i></div>
                <a href="<?php echo e(route('cart.show')); ?>" title="giỏ hàng" id="cart-respon-wp" class="fl-right">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <span id="num" class="num-total"><?php echo e(Cart::count()); ?></span>
                </a>
                <div id="cart-wp" class="fl-right">
                    <div id="btn-cart">
                        <a href="<?php echo e(route('cart.show')); ?>" title="Giỏ hàng">
                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        </a>
                        <span id="num" class="num-total"><?php echo e(Cart::count()); ?></span>
                    </div>
                    <div id="dropdown-cart-wp">
                        <?php if(Cart::count() > 0): ?>
                            <div id="dropdown">
                                <p class="desc">Có <span class="num-total"><?php echo e(Cart::count()); ?></span> sản phẩm trong
                                    giỏ hàng</p>
                                <ul class="list-cart">
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="clearfix">
                                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->options->slug_category, 'slugProduct' => $item->options->slug_product])); ?>"
                                                title="" class="thumb fl-left">
                                                <img src="<?php echo e(asset($item->options->image_product)); ?>" alt="">
                                            </a>
                                            <div class="info fl-right">
                                                <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->options->slug_category, 'slugProduct' => $item->options->slug_product])); ?>"
                                                    title="" class="product-name"><?php echo e($item->name); ?></a>
                                                <p class="price">
                                                    <?php echo e(number_format($item->price * $item->qty, 0, ',', '.')); ?>đ</p>
                                                <div class="color_qty d-flex">
                                                    <p class="color_name mr-3">Màu: <span
                                                            class="font-weight-bold"><?php echo e($item->options->color_name); ?></span>
                                                    </p>
                                                    <p class="qty">Số lượng: <span
                                                            class="font-weight-bold"><?php echo e($item->qty); ?></span></p>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <div class="total-price clearfix">
                                    <p class="title fl-left">Tổng:</p>
                                    <p class="price fl-right text-danger total-cart">
                                        <?php echo e(number_format(Cart::total(), 0, ',', '.')); ?>đ</p>
                                </div>
                                <div class="action-cart clearfix">
                                    <a href="<?php echo e(route('cart.show')); ?>" title="Giỏ hàng" class="view-cart fl-left">Giỏ
                                        hàng</a>
                                    <a href="<?php echo e(route('user.checkout')); ?>" title="Thanh toán"
                                        class="checkout fl-right">Thanh toán</a>
                                </div>
                            </div>
                        <?php else: ?>
                            <div id="cart-empty">
                                <p class="desc">Không có sản phẩm trong giỏ hàng</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/components/header.blade.php ENDPATH**/ ?>