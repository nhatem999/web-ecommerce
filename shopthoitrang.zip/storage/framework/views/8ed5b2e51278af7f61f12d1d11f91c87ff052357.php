<div class="sidebar fl-left">
    
    <?php echo $__env->make('user.components.categoryProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <div class="section" id="filter-product-wp">
        <div class="section-head">
            <h3 class="section-title">Bộ lọc</h3>
        </div>
        <div class="section-detail">
            <form>
                <table>
                    <thead>
                        <tr>
                            <td colspan="2">Hãng</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $catFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" name="r-brand[]" value="<?php echo e($item->slug); ?>"
                                        id="<?php echo e($item->id); ?>" <?php if(is_array($checkBrand)): ?> <?php echo e(in_array($item->slug, $checkBrand) ? 'checked' : ''); ?> <?php endif; ?>
                                        <?php echo e($item->slug == $catCheck ? 'checked' : ''); ?> />
                                </td>
                                <td><label for="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></label></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table>
                    <thead>
                        <tr>
                            <td colspan="2">Giá</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="radio" <?php echo e($checkPrice == 'duoi-3-trăm' ? 'checked' : ''); ?>

                                    name="r-price" value="duoi-3-trăm" id="-300000"></td>
                            <td><label for="-300000">Dưới 300.000đ</label></td>
                        </tr>
                        <tr>
                            <td><input type="radio" <?php echo e($checkPrice == 'tu-3-4-trăm' ? 'checked' : ''); ?>

                                    name="r-price" value="tu-3-4-trăm" id="300000-400000"></td>
                            <td><label for="3000-400000">300.000đ - 400.000đ</label></td>
                        </tr>
                        
                    </tbody>
                </table>
                <div class="text-center">
                    <input type="submit" class="btn btn-outline-primary" value="Xem kết quả">
                </div>
            </form>
        </div>
    </div>
    
    <div class="section" id="banner-wp">
        <div class="section-detail">
            <a href="<?php echo e(route('user.index')); ?>" title="" class="thumb">
                <img src="<?php echo e(asset('public/users/images/Banner1.png')); ?>" alt="">
            </a>
        </div>
    </div>

</div>
<?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/product/componentSidebar.blade.php ENDPATH**/ ?>