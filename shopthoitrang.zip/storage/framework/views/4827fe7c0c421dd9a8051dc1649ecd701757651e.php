
<?php $__env->startSection('title', 'Danh sách vai trò'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách sản phẩm</h5>
                <div class="form-search form-inline">
                    <form action="">
                        <input type="text" class="form-control form-search" name="kw" placeholder="Tìm kiếm tên vai trò"
                            value="<?php echo e(request()->kw); ?>">
                        <input type="submit" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('errors')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('errors')); ?>

                    </div>
                <?php endif; ?>
                <table class="table table-striped table-checkall" id="list-product">
                    <thead class="text-center">
                        <tr>
                            <th scope="col">
                                <input name="checkall" type="checkbox">
                            </th>
                            <th scope="col">#</th>
                            <th scope="col" width="10%">Tên vai trò</th>
                            <th scope="col" width="50%">Các quyền</th>
                            <th scope="col">Miêu tả</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($roles->count() > 0): ?>
                            <?php
                                $t = 1;
                            ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="list_check[]" value="<?php echo e($item->id); ?>">
                                    </td>
                                    <td><?php echo e($t++); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $item->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span
                                                class="badge bg-success text-white"><?php echo e($permission->display_name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td>
                                        <?php if(Auth::user()->can('sua-vai-tro')): ?>
                                            <a href="<?php echo e(route('role.update', ['id' => $item->id])); ?>"
                                                class="btn btn-success btn-sm rounded-0" data-toggle="tooltip"
                                                title="Edit"><i class="fa fa-edit"></i></a>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->can('xoa-vai-tro')): ?>
                                            <a href="<?php echo e(route('role.delete', ['id' => $item->id])); ?>"
                                                onclick="return confirm('Bán có chắc chắn muốn xóa bản ghi này')"
                                                class="btn btn-danger btn-sm rounded-0" data-toggle="tooltip"
                                                title="Delete"><i class="fa fa-trash"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5">Không có bản ghi nào</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($roles->appends(request()->input())->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/admin/role/list.blade.php ENDPATH**/ ?>