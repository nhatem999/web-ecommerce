
<?php $__env->startSection('title', 'Xác thực tài khoản'); ?>

<?php $__env->startSection('content'); ?>
         <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <?php if(Auth::guard('account')->user()->verify_account == 1): ?>
            <p style='text-align: center;
            font-size: large;
            color: cornflowerblue;'>Tài khoản này đã được xác thực</p>
        <?php else: ?>
     
            <form action="<?php echo e(route('user.verify-sendmail', ['id' => Auth::guard('account')->user()->id])); ?>" method="get" style="    text-align: center;
                font-size: large;
                color: blueviolet;
            }">
                <?php echo csrf_field(); ?>
                <label for="" style="margin-bottom:10px">Nhận mã xác thực</label><br>
                <button type="submit">Nhận mã</button>
            </form>
        <?php endif; ?>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/login/verify.blade.php ENDPATH**/ ?>