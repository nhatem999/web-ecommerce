<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>