
<?php $__env->startSection('title', 'Giỏ hàng'); ?>
<?php $__env->startSection('main_class', 'cart-page'); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="section" id="breadcrumb-wp">
        <div class="section-detail">
            <ul class="list-item clearfix">
                <li>
                    <a href="<?php echo e(route('user.index')); ?>" title="Trang chủ">Trang chủ</a>
                </li>
                <li>
                    <a href="<?php echo e(route('cart.show')); ?>" title="Giỏ hàng">Giỏ hàng</a>
                </li>
            </ul>
        </div>
    </div>
    <div id="wrapper" class="wp-inner clearfix">
        <?php if(Cart::count() > 0): ?>
            <div class="section" id="info-cart-wp">
                <div class="section-detail table-responsive">
                    <table class="table">
                        <thead>
                            <tr class="text-center">
                                <th width="10%">Ảnh sản phẩm</th>
                                <th>Tên sản phẩm</th>
                                <th>Màu sản phẩm</th>
                                <th>Kích thước sản phẩm</th>
                                <th>Giá sản phẩm</th>
                                <th>Số lượng</th>
                                <th>Thành tiền</th>
                                <th>Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->options->slug_category, 'slugProduct' => $item->options->slug_product])); ?>"
                                            title="">
                                            <img class="img-thumbnail" src="<?php echo e(asset($item->options->image_product)); ?>"
                                                alt="">
                                        </a>
                                    </td>
                                    <td class="text-left">
                                        <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->options->slug_category, 'slugProduct' => $item->options->slug_product])); ?>"
                                            title="" class="name-product"><?php echo e($item->name); ?></a>
                                    </td>
                                    <td><?php echo e($item->options->color_name); ?></td>
                                    <td><?php echo e($item->options->size_name); ?></td>
                                    <td><?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</td>
                                    <td>
                                        <div class="num-product-wp" data-url="<?php echo e(route('cart.update')); ?>">
                                            <a title="" class="minus <?php echo e($item->qty == 1 ? 'disabled' : ''); ?>"><i
                                                    class="fa fa-minus"></i></a>
                                            <input type="text" disabled="disabled" name="num-order-cart"
                                                value="<?php echo e($item->qty); ?>" class="num-order-cart"
                                                data-rowid=<?php echo e($item->rowId); ?>>
                                            <a title="" class="plus"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </td>
                                    <td id="sub-total-<?php echo e($item->rowId); ?>">
                                        <?php echo e(number_format($item->price * $item->qty, 0, ',', '.')); ?>đ</td>
                                    <td>
                                        <a href="" data-url="<?php echo e(route('cart.delete', ['rowId' => $item->rowId])); ?>"
                                            data-rowId=<?php echo e($item->rowId); ?>

                                            class="btn btn-danger btn-sm rounded-0 text-white action_delete"
                                            title="Delete"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="7">
                                    <div class="clearfix">
                                        <p id="total-price" class="fl-right">Tổng giá:
                                            <span class="total-cart"><?php echo e(number_format(Cart::total(), 0, ',', '.')); ?>đ
                                            </span>
                                        </p>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="7">
                                    <div class="clearfix">
                                        <div class="fl-right">
                                            <a href="<?php echo e(route('user.checkout')); ?>" title="" id="checkout-cart">Thanh
                                                toán</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="section" id="action-cart-wp">
                <div class="section-detail">
                    <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Nhập vào số
                        lượng
                        <span>0</span> để xóa sản phẩm khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.
                    </p>
                    <a href="<?php echo e(route('user.index')); ?>" title="Trang chủ" id="buy-more">Mua tiếp</a><br />
                    <a href="<?php echo e(route('cart.delete', ['rowId' => 'all'])); ?>" title="" id="delete-cart">Xóa giỏ
                        hàng</a>
                </div>
            </div>
        <?php else: ?>
            <div class="not-cart">
                <img src="<?php echo e(asset('public/users/images/cart-empty.png')); ?>" alt="">
                <p>Không có sản phẩm nào trong giỏ hàng của bạn</p>
                <a href="<?php echo e(route('user.index')); ?>" class="btn btn-outline-success" title="trang chủ">Quay trở về Trang
                    chủ Ismart Store</a>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('public/sweetAlert2/sweetalert2@11.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('public/users/js/cart.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/cart/show.blade.php ENDPATH**/ ?>