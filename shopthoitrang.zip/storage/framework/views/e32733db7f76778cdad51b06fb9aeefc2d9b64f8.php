<?php $__currentLoopData = $catPostChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row"><?php echo e($t); ?></th>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->slug); ?></td>
        <?php if($item->parent_id == 0): ?>
            <td>None</td>
        <?php else: ?>
            <td><?php echo e($item->catPostParent->name); ?></td>
        <?php endif; ?>
        <td>
            <a href="" class="btn btn-success btn-sm rounded-0 text-white" type="button" data-toggle="tooltip"
                data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
            <a href="" onclick="return confirm('Bạn chắc chắn xóa bản ghi này')"
                class="btn btn-danger btn-sm rounded-0 text-white" type="button" data-toggle="tooltip"
                data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
        </td>
    </tr>
    <?php echo $__env->make('admin.categoryPost.catPostChild', ['catPostChild' => $item->catPostChild], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/admin/categoryPost/catPostChild.blade.php ENDPATH**/ ?>