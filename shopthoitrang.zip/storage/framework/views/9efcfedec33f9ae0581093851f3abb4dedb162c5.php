
<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('main_class', 'detail-product-page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="secion" id="breadcrumb-wp">
        <div class="secion-detail">
            <ul class="list-item clearfix">
                <li>
                    <a href="" title="">Trang chủ</a>
                </li>
                <li>
                    <a href="<?php echo e(route('user.category', $cat->slug)); ?>" title=""><?php echo e($cat->name); ?></a>
                </li>
                <li>
                    <a href="<?php echo e(route('user.category', $product->category->slug)); ?>"
                        title=""><?php echo e($product->category->name); ?></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-content fl-right">
        <div class="section" id="detail-product-wp">
            <div class="section-detail clearfix">
                <div class="thumb-wp fl-left">
                    <ul id="imageGallery">
                        <?php $__currentLoopData = $productColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-thumb="<?php echo e(asset($item->image_color_path)); ?>"
                                data-src="<?php echo e(asset($item->image_color_path)); ?>">
                                <img class="img-thumbnail img-product" src="<?php echo e(asset($item->image_color_path)); ?>" />
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $productImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-thumb="<?php echo e(asset($item->image_product)); ?>"
                                data-src="<?php echo e(asset($item->image_product)); ?>">
                                <img class="img-thumbnail img-product" src="<?php echo e(asset($item->image_product)); ?>" />
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="thumb-respon-wp fl-left">
                    <img src="<?php echo e(asset('public/users/images/test6.jpg')); ?>" alt="">
                </div>
                <div class="info fl-right">
                    <h3 class="product-name"><?php echo e($product->name); ?></h3>
                    <div class="desc d-flex">
                        <?php
                            $t = 1;
                        ?>
                        <?php $__currentLoopData = $productColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-color <?php echo e($key == 0 ? 'active' : ''); ?>" data-id="<?php echo e($t++); ?>">
                                <div class='img img-detail-product'>
                                    <img src="<?php echo e(asset($item->image_color_path)); ?>" alt="">
                                    <input type="radio" <?php echo e($key == 0 ? 'checked' : ''); ?> name="check-color-detail"
                                        value="<?php echo e($item->id); ?>" />
                                    <p class="color-name"><?php echo e($item->color->name); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="num-product">
                        <span class="title">Sản phẩm: </span>
                        <span class="status">Còn hàng</span>
                    </div>
                    <p class="price"><?php echo e(number_format($product->price, 0, '', '.')); ?>đ</p>
                    <div id="num-order-detail-wp">
                        <a title="" class="minus"><i class="fa fa-minus"></i></a>
                        <input type="text" name="num-order" value="1" class="num-order" disabled="disabled">
                        <a title="" class="plus"><i class="fa fa-plus"></i></a>
                    </div>
                    <p class="add-cart text-center"><a href="<?php echo e(route('cart.add', $product->id)); ?>" title="Đặt hàng"
                            data-name="<?php echo e($item->name); ?>">Thêm giỏ hàng</a></p>
                </div>
            </div>
        </div>
        <div class="section" id="post-product-wp">
            <div class="section-head">
                <h3 class="section-title">Mô tả sản phẩm</h3>
            </div>
            <div class="section-detail">
                <div class="product-detail detail-hide">
                    <?php echo $product->description; ?>

                </div>
                <div class="read-more">
                    <a href="#" class="show_hide" data-content="toggle-text">Read More</a>
                </div>
            </div>
        </div>
        <div class="section" id="same-category-wp">
            <div class="section-head">
                <h3 class="section-title">Cùng chuyên mục</h3>
            </div>
            <div class="section-detail">
                <ul class="list-item">
                    <?php $__currentLoopData = $sameProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="product-laptop">
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="thumb">
                                <img src="<?php echo e(asset($item->feature_image)); ?>">
                            </a>
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                            </div>
                            <div class="action clearfix">
                                <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title="Thêm giỏ hàng"
                                    class="add-cart fl-left" data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>">Thêm
                                    giỏ hàng</a>
                                <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua
                                    ngay</a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('public/users/js/detail_product.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/user/product/detail.blade.php ENDPATH**/ ?>