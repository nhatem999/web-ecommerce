<div class="section" id="slider-wp">
    <div class="section-detail">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <img src="<?php echo e(asset($item->image_path)); ?>" alt="<?php echo e($item->image_name); ?>">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/components/slider.blade.php ENDPATH**/ ?>