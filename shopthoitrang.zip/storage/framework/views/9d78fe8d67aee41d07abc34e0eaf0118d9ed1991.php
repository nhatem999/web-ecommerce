<ul class="sub-menu">
    <?php $__currentLoopData = $categoryProductChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('user.category', $item->slug)); ?>" title=""><?php echo e($item->name); ?></a>
            <?php if($item->catProductChild->count() > 0): ?>
                <?php echo $__env->make('user.components.categoryProductChild' , ['categoryProductChild' => $item->catProductChild], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/components/categoryProductChild.blade.php ENDPATH**/ ?>