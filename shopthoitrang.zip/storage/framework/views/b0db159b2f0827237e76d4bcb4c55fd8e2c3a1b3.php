
<?php $__env->startSection('title'); ?>
    <?php if(empty($slug)): ?>
        Tin mới
    <?php else: ?>
        <?php echo e($catName->name); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_class', 'blog-page'); ?>
<?php $__env->startSection('content'); ?>
<div class="secion" id="breadcrumb-wp">
    <div class="secion-detail">
        <ul class="list-item clearfix">
            <li>
                <a href="<?php echo e(route('user.index')); ?>" title="">Trang chủ</a>
            </li>
            <li>
                <a href="<?php echo e(route('user.blog')); ?>" title="">Blog</a>
            </li>
            <?php if(!empty($slug)): ?>
                <li>
                    <a href="<?php echo e(route('user.blog', $slug)); ?>" title=""><?php echo e($catName->name); ?></a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<div class="main-content fl-right">
    <div class="section" id="list-blog-wp">
        <div class="section-head clearfix">
            <h3 class="section-title">Blog</h3>
        </div>
        <div class="section-menu">
            <ul class="nav nav-tabs">
                <?php $__currentLoopData = $catPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($item['slug'] == $slug ? 'active' : ''); ?>"
                            href="<?php echo e(route('user.blog', ['slug' => $item['slug']])); ?>"><?php echo e($item['name']); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="section-detail">
            <ul class="list-item blog-main">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $slugCate = $item->category->slug;
                        $param_url = [
                            'slugCate' => $slugCate,
                            'slugPost' => $item->slug,
                        ];
                    ?>
                    <li class="clearfix">
                        <a href="<?php echo e(route('user.postDetail', $param_url)); ?>" title="" class="thumb fl-left">
                            <img src="<?php echo e(asset($item->image_post)); ?>" alt="<?php echo e($item->title); ?>">
                        </a>
                        <div class="info fl-right">
                            <a href="<?php echo e(route('user.postDetail', $param_url)); ?>" title=""
                                class="title"><?php echo e($item->title); ?></a>
                            <span class="create-date"><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></span>
                            <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham
                                quan
                                các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên
                                phần mềm
                                Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát
                                Lái... để
                                kiều bào hiểu thêm về tình hình phát [...]</p>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="section" id="paging-wp">
        <div class="section-detail">
            
            <?php if(!empty($slug)): ?>
                <?php echo e($posts->links()); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/blog/blog.blade.php ENDPATH**/ ?>