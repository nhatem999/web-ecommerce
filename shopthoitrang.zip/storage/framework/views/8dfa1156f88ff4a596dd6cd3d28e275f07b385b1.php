
<?php $__env->startSection('title', 'Thanh toán đơn hàng'); ?>
<?php $__env->startSection('main_class', 'checkout-page'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section" id="breadcrumb-wp">
        <div class="section-detail">
            <ul class="list-item clearfix">
                <li>
                    <a href="<?php echo e(route('user.index')); ?>" title="Trang chủ">Trang chủ</a>
                </li>
                <li>
                    <a href="<?php echo e(route('user.checkout')); ?>" title="Thanh toán">Thanh toán</a>
                </li>
            </ul>
        </div>
    </div>
    <div id="wrapper" class="wp-inner clearfix">
        <form method="POST" action="<?php echo e(route('user.postCheckout')); ?>" name="form-checkout" id="form-checkout">
            <?php echo csrf_field(); ?>
            <div class="section" id="customer-info-wp">
                <div class="section-head">
                    <h1 class="section-title">Thông tin khách hàng</h1>
                </div>
                <div class="section-detail">
                    <div class="form-row clearfix">
                        <div class="form-col fl-left">
                            <label for="fullname">Họ tên</label>
                            <input type="text" name="fullname" id="fullname" value="<?php echo e(old('fullname')); ?>"
                                placeholder="Nhập họ tên người nhận">
                            <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-col fl-right">
                            <label for="phone">Số điện thoại</label>
                            <input type="text" name="phone" id="phone" value="<?php echo e(old('phone')); ?>"
                                placeholder="Nhập số điện thoại người nhận">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="email">Email</label>
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>" id="email"
                                placeholder="Nhập email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row clearfix">
                        <div class="form-col fl-left">
                            <label for="address">Tỉnh/Thành phố</label>
                            <select name="calc_shipping_provinces" id="provinces">
                                <option value="">Tỉnh / Thành phố</option>
                            </select>
                            <?php $__errorArgs = ['calc_shipping_provinces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-col fl-right">
                            <label for="address">Quận/Huyện</label>
                            <select name="calc_shipping_district" id="district">
                                <option value="">Quận / Huyện</option>
                            </select>
                            <?php $__errorArgs = ['calc_shipping_district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input class="billing_address_1" name="" type="hidden" value="">
                        <input class="billing_address_2" name="" type="hidden" value="">
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="address">Địa chỉ</label>
                            <input type="text" name="address" id="address" placeholder="Nhập số nhà, đường, phường ...."
                                value="<?php echo e(old('address')); ?>">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section" id="order-review-wp">
                <div class="section-head">
                    <h1 class="section-title">Thông tin đơn hàng</h1>
                </div>
                <div class="section-detail">
                    <table class="shop-table">
                        <thead>
                            <tr>
                                <td colspan="3">Sản phẩm</td>
                                <td>Tổng</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $checkoutProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="cart-item">
                                    <td class="product-img" width="22%">
                                        <img src="<?php echo e(asset($item->options->image_product)); ?>" alt="">
                                    </td>
                                    <td class="product-info pl-2">
                                        <p class="product-name"><?php echo e($item->name); ?><strong class="product-quantity">x
                                                <?php echo e($item->qty); ?></strong>
                                        </p>
                                        <p class="product-price"><?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</p>
                                    </td>
                                    <td class="product-color text-center" width="15%"><?php echo e($item->options->color_name); ?>

                                    </td>
                                    <td class="product-color text-center" width="15%"><?php echo e($item->options->size_name); ?></td>
                                    <td class="product-total">
                                        <?php echo e(number_format($item->price * $item->qty, 0, ',', '.')); ?>đ
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="order-total">
                                <td colspan="2">Tổng đơn hàng ( <?php echo e($numProducts); ?> sản phẩm ) :</td>
                                <td colspan="2">
                                    <strong class="total-price"><?php echo e(number_format($totalPrice, 0, ',', '.')); ?>đ</strong>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <div class="place-order-wp clearfix">
                        <input type="button" id="order-now" name="btn-checkout" value="Đặt hàng">
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('public/sweetAlert2/sweetalert2@11.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('public/users/js/cart.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('public/select2/select2.min.js')); ?>"></script>
    <script src='https://cdn.jsdelivr.net/gh/vietblogdao/js/districts.min.js'></script>
    <script>
        //<![CDATA[
        if (address_2 = localStorage.getItem('address_2_saved')) {
            $('select[name="calc_shipping_district"] option').each(function() {
                if ($(this).text() == address_2) {
                    $(this).attr('selected', '')
                }
            })

            $('input.billing_address_2').attr('value', address_2)
        }
        if (district = localStorage.getItem('district')) {
            $('select[name="calc_shipping_district"]').html(district)
            $('select[name="calc_shipping_district"]').on('change', function() {
                var target = $(this).children('option:selected')
                target.attr('selected', '')
                $('select[name="calc_shipping_district"] option').not(target).removeAttr('selected')
                address_2 = target.text()
                $('input.billing_address_2').attr('value', address_2)
                district = $('select[name="calc_shipping_district"]').html()
                localStorage.setItem('district', district)
                localStorage.setItem('address_2_saved', address_2)
            })
        }
        $('select[name="calc_shipping_provinces"]').each(function() {
            var $this = $(this),
                stc = ''
            c.forEach(function(i, e) {
                e += +1
                stc += '<option value="' + i + '">' + i + '</option>'
                $this.html('<option value="">Tỉnh / Thành phố</option>' + stc)
                if (address_1 = localStorage.getItem('address_1_saved')) {
                    $('select[name="calc_shipping_provinces"] option').each(function() {
                        if ($(this).text() == address_1) {
                            $(this).attr('selected', '')
                        }
                    })
                    $('input.billing_address_1').attr('value', address_1)
                }
                $this.on('change', function(i) {
                    i = $this.children('option:selected').index() - 1
                    var str = '',
                        r = $this.val()
                    if (r != '') {
                        arr[i].forEach(function(el) {
                            str += '<option value="' + el + '">' + el + '</option>'
                            $('select[name="calc_shipping_district"]').html(
                                '<option value="">Quận / Huyện</option>' + str)
                        })
                        var address_1 = $this.children('option:selected').text()
                        var district = $('select[name="calc_shipping_district"]').html()
                        localStorage.setItem('address_1_saved', address_1)
                        localStorage.setItem('district', district)
                        $('select[name="calc_shipping_district"]').on('change', function() {
                            var target = $(this).children('option:selected')
                            target.attr('selected', '')
                            $('select[name="calc_shipping_district"] option').not(target)
                                .removeAttr('selected')
                            var address_2 = target.text()
                            $('input.billing_address_2').attr('value', address_2)
                            district = $('select[name="calc_shipping_district"]').html()
                            localStorage.setItem('district', district)
                            localStorage.setItem('address_2_saved', address_2)
                        })
                    } else {
                        $('select[name="calc_shipping_district"]').html(
                            '<option value="">Quận / Huyện</option>')
                        district = $('select[name="calc_shipping_district"]').html()
                        localStorage.setItem('district', district)
                        localStorage.removeItem('address_1_saved', address_1)
                    }
                })
            })
        })

        $('#provinces').select2();
        $('#district').select2();

        $('input[name=btn-checkout]').click(function() {
            Swal.fire({
                title: 'Xác nhận đơn hàng',
                text: "Bạn chắc chắn với đơn hàng mình đặt!!",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Vâng, xác nhận'
            }).then((result) => {
                if (result.isConfirmed) {
                    $("form#form-checkout").submit()
                }
            })
        })
        //]]>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/cart/checkout.blade.php ENDPATH**/ ?>