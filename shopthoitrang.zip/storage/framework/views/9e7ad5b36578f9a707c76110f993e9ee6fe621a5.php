
    <!-- Button trigger modal -->
    

    <!-- Modal -->
    <div class="modal fade" id="modalAccount" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="color:orange">Thông báo đăng nhập</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                   <p style="color:blue"> Bạn cần đăng nhập để đặt hàng !!!</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    
                </div>
            </div>
        </div>
    </div>


<?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/components/modalAccountCart.blade.php ENDPATH**/ ?>