
<?php $__env->startSection('title', 'Cập nhật slider'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Cập nhật slider
                    </div>
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Ảnh slider</label>
                                <input id="img" type="file" name="image_path" class="form-control d-none"
                                    onchange="changeImg(this)">
                                <img id="avatar" class="img-thumbnail d-block" width="250px"
                                    src="<?php echo e(asset($slider->image_path)); ?>">
                                <?php $__errorArgs = ['image_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="">Trạng thái</label>
                                <div class="form-check">
                                    <input class="form-check-input" <?php if($slider->status == 1): ?> checked <?php endif; ?> type="radio" name="status" value="1"
                                        id="public">
                                    <label class="form-check-label" for="public">
                                        Công khai
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" <?php if($slider->status == 0): ?> checked <?php endif; ?> type="radio" name="status" value="0"
                                        id="pending">
                                    <label class="form-check-label" for="pending">
                                        Chờ duyệt
                                    </label>
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Cập nhật">
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/admin/slider/update.blade.php ENDPATH**/ ?>