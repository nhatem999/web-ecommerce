
<?php $__env->startSection('title', 'Thông tin đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <h1 style="    font-size: 16px;
        color: brown;margin-bottom:25px">Thông tin đơn hàng</h1>
        <table class="table table-striped table-checkall" id="list-product">
            <thead class="text-center">
                <tr>

                    <th scope="col">STT</th>
                    <th scope="col">Mã đơn hàng</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Họ và tên</th>
                    <th scope="col">Số sản phẩm</th>
                    <th scope="col">Kích thước</th>
                    <th scope="col">Màu</th>
                    <th scope="col">Tổng giá</th>
                    <th scope="col">Trang thái</th>

                </tr>
            </thead>
            <tbody class="text-center">
                <?php if($orderDetail->count() > 0): ?>
                    <?php
                        $t = 1;
                    ?>
                    <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($t++); ?></td>
                            <td><?php echo e($item->order_id); ?></td>
                            <td width="10%"><img src="<?php echo e(asset($item->productDetails->feature_image)); ?>" alt=""> </td>
                            <td><?php echo e($item->order->customer->name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($item->size); ?></td>
                            <td><?php echo e($item->color); ?></td>

                            <td><?php echo e(number_format($item->order->total, 0, ',', '.')); ?>đ</td>
                            <td>
                                <?php if($item->order->status == 0): ?>
                                    <span class="badge badge-warning">Đang xử lý</span>
                                <?php elseif($item->order->status == 1): ?>
                                    <span class="badge badge-info">Đang giao hàng</span>
                                <?php else: ?>
                                   <span class="badge badge-success"> Hoàn thành</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p style="    text-align: center;
                    padding: 10px;
                    color: red;
                    font-weight: bold;
                    font-size: 20px;">Không có đơn hàng nào</p>
                <?php endif; ?>


            </tbody>
        </table>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPRO\shopthoitrang\resources\views/user/cart/cartUser.blade.php ENDPATH**/ ?>