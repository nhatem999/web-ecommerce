<div class="sidebar fl-left">
    
    <?php echo $__env->make('user.components.categoryProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="section" id="selling-wp">
        <div class="section-head">
            <h3 class="section-title">Sản phẩm bán chạy</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                <?php $__currentLoopData = $sellProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="clearfix">
                        <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                            title="" class="thumb fl-left">
                            <img class="img-product-sell" src="<?php echo e(asset($item->feature_image)); ?>">
                        </a>
                        <div class="info fl-right">
                            <a href="<?php echo e(route('product.detail', ['slugCategory' => $item->category->catProductParent->slug, 'slugProduct' => $item->slug])); ?>"
                                title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ</span>
                            </div>
                            <a href="<?php echo e(route('cart.addProduct', ['id' => $item->id])); ?>" title=""
                                class="add-cart btn btn-outline-dark btn-sm"
                                data-url="<?php echo e(route('cart.add', ['id' => $item->id])); ?>">Thêm
                                giỏ hàng</a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="section" id="banner-wp">
        <div class="section-detail">
            <a href="<?php echo e(route('user.index')); ?>" title="" class="thumb">
                <img src="<?php echo e(asset('public/users/images/banner.png')); ?>" alt="">
            </a>
        </div>
    </div>
</div>

<?php echo $__env->make('user.components.modalProductCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('user.components.modalNotification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/user/components/sidebar.blade.php ENDPATH**/ ?>