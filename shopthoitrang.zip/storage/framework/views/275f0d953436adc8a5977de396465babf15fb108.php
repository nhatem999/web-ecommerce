
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/admins/css/seen.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="container">
            <div class="row main-content">
                <div class="col-md-12 detail-content">
                    <div class="section-head clearfix">
                        <h3 class="section-title"><?php echo e($post->title); ?></h3>
                    </div>
                    <div class="section-detail">
                        <span class="create-date"><i
                                class="far fa-clock"></i><?php echo e(date('d/m/Y', strtotime($post->created_at))); ?></span>
                        <div class="detail">
                            <?php echo $post->content; ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('post.list')); ?>" class="btn btn-primary">Quay lai</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\laravel-pro\project\ismart\resources\views/admin/post/seen.blade.php ENDPATH**/ ?>